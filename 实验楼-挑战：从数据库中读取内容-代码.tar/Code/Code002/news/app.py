#!/usr/bin/env python3
#-*- coding:utf-8 -*-
from flask import Flask ,render_template,abort
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
#import os,json
'''
result = {}
directory = os.path.join(os.getcwd(),'..','files')
for i in os.listdir(directory):
	file_path = os.path.join(directory,i)
	with open(file_path) as f:
		result[i[:-5]] = json.load(f)

'''

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/shiyanlou'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Category(db.Model):
    id = db.Column(db.Integer,primary_key=True)
    name = db.Column(db.String(80))

    def __init__(self,a):
        self.name = a

    def __repr__(self):
        return '<Category: {}>'.format(self.name)

class File(db.Model):
    id = db.Column(db.Integer,primary_key=True)
    title = db.Column(db.String(80))
    create_time = db.Column(db.DateTime,default=datetime.now)
    category_id = db.Column(db.Integer,db.ForeignKey('category.id'))
    category = db.relationship('Category',backref='file')
    content = db.Column(db.Text)
    def __init__(self,a,t,b,c):
        self.title = a
        self.category = b
        self.content = c
        self.create_time = t

    def __repr__(self):
        return '<File:{}>'.format(self.title)



@app.route('/')
def index():
    # show file list
    # ./files json title
    #l = [i['title'] for i in result.values()]
    #print(l)
    #return render_template('index.html',l=l)
    return render_template('index.html',l=File.query.all())

#@app.route('/files/<filename>')
'''
def file(filename):
    f = result.get(filename)
    if not f:
        abort(404)

    return render_template('file.html',f=f)
'''
@app.route('/files/<file_id>')
def file(file_id):
    f = File.query.get_or_404(file_id)
    return render_template('file.html',f=f)


@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'),404


if __name__ == '__main__':
    db.create_all()
    java = Category('Java')
    python = Category('Python')
    file1 = File('Hello Java',datetime.utcnow(),java,'File content - Java is cool !')
    file2 = File('Hello Python',datetime.utcnow(),python,'File content -Python is cool!')
    db.session.add(java)
    db.session.add(python)
    db.session.add(file1)
    db.session.add(file2)
    db.session.commit()

